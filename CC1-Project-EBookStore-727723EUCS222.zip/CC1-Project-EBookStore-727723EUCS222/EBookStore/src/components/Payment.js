// src/components/Payment.js

import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import './Payment.css';
import standard from '../components/standard.webp';
import delexue from '../components/deluxe.jpg';
import suite from '../components/suite.jpg';
import Acc from '../components/accessible.jpg';
import family from '../components/family.webp';
import oceanview from '../components/oceanview.webp';
import connecting from '../components/connecting.webp';
import villa from '../components/villa.jpg';

// Sample room data (in a real app, you might fetch this from an API or state)
const roomData = [
  {
    id: 1,
    name: 'Basics Of Indian Stock Market',
    description: 'Learn Markets From Scratch (Financial Education).',
    price: 'Rs.350',
    image: standard // Replace with actual image path
  },
  {
    id: 2,
    name: 'BROKEN',
    description: 'You want to know the secret to everlasting happiness?.',
    price: 'Rs.550',
    image: delexue // Replace with actual image path
  },
  {
    id: 3,
    name: 'GOD OF VENGEANCE',
    description: 'USA Today & Wall Street Journal bestselling author Michelle Heard.',
    price: 'Rs.650',
    image: suite // Replace with actual image path
  },
  {
    id: 4,
    name: 'HARRY POTTER AND THE CHAMBER OF SECRETS',
    description: 'A plot to make most terrible things happen at Hogwarts School of Witchcraft and Wizardry this year. ',
    price: 'Rs.699',
    image: Acc// Replace with actual image path
  },
  {
    id: 5,
    name: 'HARRY POTTER AND THE PHILOSOPHERS STONE',
    description: 'Harry saw a purple wax seal bearing a coat of arms; a lion, an eagle, a badger and a snake surrounding a large letter H.',
    price: 'Rs.759',
    image: family// Replace with actual image path
  },
  {
    id: 6,
    name: 'HARRY PORTER AND THE HALF-BLOOD PRINCE',
    description: 'You are sharing the Dark Lords thoughts and emotions.',
    price: 'Rs.799',
    image: oceanview// Replace with actual image path
  },
  {
    id: 7,
    name: 'MASTERING MACD',
    description: 'Moving average convergence - Histogram Indicator for Investing and Trading..',
    price: 'Rs.1200',
    image: connecting
  },
  {
    id: 8,
    name: 'THE BONUS',
    description: 'From Wall Street Journal, BookTok: Author T L Swan comes the sizzling story of Gabriel Ferrara and Grace Porter.',
    price: 'Rs.1800',
    image: villa
  },
];

const Payment = () => {
  const { roomId } = useParams();
  const [room, setRoom] = useState(null);
  const [bookingDateTime, setBookingDateTime] = useState('');
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const selectedRoom = roomData.find((room) => room.id === parseInt(roomId));
    setRoom(selectedRoom);
  }, [roomId]);

  const handlePayment = () => {
    if (bookingDateTime) {
      setPaymentSuccess(true);
    } else {
      alert('Please select a date and time for booking.');
    }
  };

  if (paymentSuccess) {
    return (
      <div className="payment-success">
        <h2>Order Placed</h2>
        <b><p>Your Order has been placed successfully.
            
           Thank you for choosing BookBuy!</p></b>
        <button onClick={() => navigate('/home')}>Go to Home</button>
      </div>
    );
  }

  return (
    <div className="payment-container">
      <h2>Payment</h2>
      {room && (
        <div className="room-details">
          <img src={room.image} alt={room.name} className="room-image" />
          <h3>{room.name}</h3>
          <p>{room.description}</p>
          <p>{room.price}</p>
        </div>
      )}
      <div className="booking-details">
        <label>
        Enter Your UPI ID: <br/><br/>
          <input
            type="Email"
            value={bookingDateTime}
            onChange={(e) => setBookingDateTime(e.target.value)}
            required
          />
        </label>
      </div>
      <button onClick={handlePayment}>Pay</button>
    </div>
  );
};

export default Payment;
