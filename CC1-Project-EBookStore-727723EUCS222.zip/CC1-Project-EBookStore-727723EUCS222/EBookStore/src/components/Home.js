import React from 'react';
import { useNavigate } from 'react-router-dom';
import './Home.css';
import standard from '../components/standard.webp';
import deluxe from '../components/deluxe.jpg';
import suite from '../components/suite.jpg';
import accessible from '../components/accessible.jpg';
import family from '../components/family.webp';
import oceanview from '../components/oceanview.webp';
import connecting from '../components/connecting.webp';
import villa from '../components/villa.jpg';
import spain from '../components/spain.webp'; 
import london from '../components/london.jpg';
import croatia from '../components/croatia.jpg'; 
import germany from '../components/germany.jpg';
// import france from '../components/france.jpeg'; 
// import italy from '../components/italy.jpeg';
// import swiss from '../components/swiss.jpeg';
// import india from '../components/india.jpeg';
// import japan from '../components/japan.jpeg'; 
// import china from '../components/china.jpeg';
// import singapore from '../components/singapore.jpeg';
// import southafr from '../components/southafr.jpeg';

// Sample data for rooms
const rooms = [
  {
    id: 1,
    name: 'Basics Of Indian Stock Market',
    description: ' Learn Markets From Scratch (Financial Education).',
    price: 'Rs.350',
    image: standard
  },
  {
    id: 2,
    name: 'BROKEN',
    description: 'You want to know the secret to everlasting happiness?',
    price: 'Rs.550',
    image: deluxe
  },
  {
    id: 3,
    name: 'GOD OF VENGEANCE',
    description: 'USA Today & Wall Street Journal bestselling author Michelle Heard.',
    price: 'Rs.650',
    image: suite
  },
  {
    id: 4,
    name: 'HARRY POTTER AND THE CHAMBER OF SECRETS',
    description: 'A plot to make most terrible things happen at Hogwarts School of Witchcraft and Wizardry this year.',
    price: 'Rs.699',
    image: accessible
  },
  {
    id: 5,
    name: 'HARRY POTTER AND THE PHILOSOPHERS STONE ',
    description: 'Harry saw a purple wax seal bearing a coat of arms; a lion, an eagle, a badger and a snake surrounding a large letter H',
    price: 'Rs.759',
    image: family
  },
  {
    id: 6,
    name: 'HARRY PORTER AND THE HALF-BLOOD PRINCE',
    description: 'You are sharing the Dark Lords thoughts and emotions.',
    price: 'Rs.799',
    image: oceanview
  },
  {
    id: 7,
    name: 'MASTERING MACD',
    description: 'Moving average convergence - Histogram Indicator for Investing and Trading..',
    price: 'Rs.1800',
    image: connecting
  },
  {
    id: 8,
    name: 'THE BONUS',
    description: 'From Wall Street Journal, BookTok: Author T L Swan comes the sizzling story of Gabriel Ferrara and Grace Porter.',
    price: 'Rs.1200',
    image: villa
  },
];


// Sample data for popular destinations
const destinations = [
  {
    id: 1,
    name: 'Cabin Brewster',
    image: spain,
  },
  {
    id: 2,
    name: 'The English Spy',
    image: london,
  },
  {
    id: 3,
    name: 'The Hidden Face',
    image: croatia,
  },
  {
    id: 4,
    name: 'The Intelligent Investor',
    image: germany,
  },
  // {
  //   id: 5,
  //   name: 'France',
  //   image: france,
  // },
  // {
  //   id: 6,
  //   name: 'Italy',
  //   image: italy,
  // },
  // {
  //   id: 7,
  //   name: 'Switzerland',
  //   image: swiss,
  // },
  // {
  //   id: 8,
  //   name: 'India',
  //   image: india,
  // },
  // {
  //   id: 9,
  //   name: 'Japan',
  //   image: japan,
  // },
  // {
  //   id: 10,
  //   name: 'China',
  //   image: china,
  // },
  // {
  //   id: 11,
  //   name: 'Singapore',
  //   image: singapore,
  // },
  // {
  //   id: 12,
  //   name: 'South Africa',
  //   image: southafr,
  // },
  
  
];

const Home = () => {
  const navigate = useNavigate();

  const handleBookRoom = (roomId) => {
    navigate(`/payment/${roomId}`);
  };

  return (
  <div>
    <div className="main" >
        <div className="navbar">
                <div className="icon">
                    <a href="" className="menulevel">
                            <div className="oneh"></div>
                            <div className="twoh"></div>
                            <div className="threeh"></div>
                           </a>
                           
                       
                        <h2 className="logo">BookBuy</h2>
                    <div className="menu ">
                        <ul>
                            <li><a href="#" className='redirect'>Home</a></li>
                            <li><a href="#" className='redirect'>Dashboard</a></li>
                            <li><a href="#" className='redirect'>Features</a></li>
                            <li><a href="#" className='redirect'>AboutUs</a></li>
                            <li><a href="#" className='redirect'>Contact</a></li>
                            <li> <button onClick={() => navigate('/')} className="login-button">Sign In</button>
                            </li>
                            <li>
                            <button onClick={() => navigate('/signup')} className="signup-button">Sign Up</button>
                            </li>
                        </ul>
                    </div>   
            </div>
        </div>
    </div>
    <div className="home-container">
      <header className="home-header">
      y
        <h1>BookBuy - ECommerce For Books</h1>
        <p>Millions of books around the world are waiting for you!</p> 
        <div className="booking-options">
          <input type="text" placeholder="Name of the Book" />
          <input type="text" placeholder="Enter Category" />
          {/* <input type="date" placeholder="Check-out" /> */}
          {/* <input type="number" placeholder="Guests" min="1" /> */}
          <button className="search-button">Search</button>
        </div>
      </header>

      <section className="popular-destinations">
        <h2>Popular Books</h2>
        <div className="destination-list">
          {destinations.map((destination) => (
            <div key={destination.id} className="destination-card">
              <img src={destination.image} alt={destination.name} className="destination-image" />
              <h3>{destination.name}</h3>
            </div>
          ))}
        </div>
      </section>

      <section className="room-options">
        <h2>New Arrivals</h2>
        <div className="room-list">
          {rooms.map((room) => (
            <div key={room.id} className="room-card">
              <img src={room.image} alt={room.name} className="room-image" />
              <h3>{room.name}</h3>
              <p>{room.description}</p>
              <p className="room-price">{room.price}</p>
              <button className="book-room-button" onClick={() => handleBookRoom(room.id)}>Buy Now</button>
            </div>
          ))}
        </div>
      </section>

      <section className="testimonials">
        <h2>What Our Customers Say</h2>
        <div className="testimonial-list">
          <div className="testimonial">
            <p>"Amazing experience! The Order has been delivered on time."</p>
            <p>- Shiva</p>
          </div>
          <div className="testimonial">
            <p>"The user experience is good at this website."</p>
            <p>- Jane Smith</p>
          </div>
          <div className="testimonial">
            <p>"A perfect solution to find books around the world!"</p>
            <p>- Emily Johnson</p>
          </div>
        </div>
      </section>

      <section className="contact-us">
        <h2>Contact Us</h2>
        <p>Have questions? Reach out to our customer support team 24/7 via phone or email.</p>
      </section>

      <footer className="site-footer">
        <p>&copy; 2024 BBE LTD. All Rights Reserved.</p>
        <p>Follow us on:</p>
        <div className="social-media-icons">
          <a href="https://facebook.com">Facebook</a> | 
          <a href="https://twitter.com">Twitter</a> | 
          <a href="https://instagram.com">Instagram</a>
        </div>
      </footer>
    </div>
  </div>
  );
};

export default Home;
