import { useEffect, Fragment, useState } from "react";
import { useParams } from "react-router-dom";
import CurrencyRupeeIcon from '@mui/icons-material/CurrencyRupee';

import { useDispatch, useSelector } from "react-redux";
import Loader from "../layouts/Loader";
import { getProduct } from "../../actions/productAction";
import { Carousel } from 'react-bootstrap';
import MetaData from "../layouts/MetaData";
import { addCartItem } from "../../actions/cartActions";
// import { decreaseCartItemQty, increaseCartItemQty } from "../../slices/cartSlice";

export default function ProductDetail() {
    
    const dispatch = useDispatch();
    const {id} =  useParams();
    const { loading, product } = useSelector((state)=>state.productState)    
    const [quantity, setQuantity] = useState(1);

    useEffect(() => {
        dispatch(getProduct(id))
        
    },[dispatch, id])

    
    const increaseQty = () => {
        const count = document.querySelector('.count')
        if(product.stock !== 0 ||  count.valueAsNumber >= product.stock) return;
        const qty = count.valueAsNumber + 1;
        setQuantity(qty);
    }
    const decreaseQty= () => {
        const count = document.querySelector('.count')
        if(count.valueAsNumber === 1) return;
        const qty = count.valueAsNumber - 1;
        setQuantity(qty);
    }
    // const increaseQuty  = (item) =>{
    //     const count = item.quantity;
    //     if(item.stock === 0 || count >= item.stock) return;
    //     dispatch(increaseCartItemQty(item.product))
    // }
    // const decreaseQuty  = (item) =>{
    //     const count = item.quantity;
    //     if(count === 1) return;
    //     dispatch(decreaseCartItemQty(item.product))
    // }
    return(
        <>
    <Fragment>
        {loading ? <Loader/> :     
        <Fragment>
            <MetaData title={product.name}/>
         <div className="row f-flex justify-content-around">
        <div className="col-12 col-lg-5 img-fluid" id="product_image">
            <Carousel pause="hover">
                {product.images && product.images.map(image => 
                    <Carousel.Item key={image._id}>

                        <img className="d-block w-100" src={image.image} alt={product.name} height="600" width="500"/>
                    </Carousel.Item>
                )}
            </Carousel>
        </div>

        <div className="col-12 col-lg-5 mt-5">
            <h3>{product.name}</h3>
            <p id="product_id">Product # {product._id}</p>

            <hr />

            <div className="rating-outer">
                <div className="rating-inner" style={{width : `${product.ratings/5 * 100}%`}} > </div>
            </div>
            <span id="no_of_reviews">({product.numOfReviews} Reviews)</span>

            <hr />
            <p id="product_price"><CurrencyRupeeIcon/>{product.price}</p>
            <div className="stockCounter d-inline">
                <span className="btn btn-danger minus" onClick={decreaseQty} >-</span>

                <input type="number" className="form-control count d-inline" value={quantity} readOnly />

                <span className="btn btn-primary plus" onClick={increaseQty} >+</span>
            </div>
             <button type="button"
             onClick={()=>dispatch(addCartItem(product._id, quantity))} 
             disabled={product.stock === 0?true:false} id="cart_btn" 
             className="btn btn-primary d-inline ml-4">Add to Cart</button>

            <hr />

            <p>Status: <span id="stock_status" className={ product.stock > 0 ? 'greenColor' : 'redColor' }>{ product.stock > 0 ? 'In Stock' : 'Out of Stock' } </span></p>

            <hr />

            <h4 className="mt-2">Description:</h4>
            <p>{product.description}</p>
            <hr />
            <p id="product_seller mb-3">Sold by: <strong> {product.seller} </strong></p>
            {/* <button id="review_btn" type="button" className="btn btn-primary mt-4" data-toggle="modal" data-target="#ratingModal">
                            Submit Your Review
                </button> */}
            {/* <div className="rating w-50">
            <div className="modal fade" id="ratingModal" tabIndex="-1" role="dialog" aria-labelledby="ratingModalLabel" aria-hidden="true">
                            <div className="modal-dialog" role="document">
                                <div className="modal-content">
                                    <div className="modal-header">
                                        <h5 className="modal-title" id="ratingModalLabel">Submit Review</h5>
                                        <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div className="modal-body">

                                        <ul className="stars" >
                                            <li className="star"><i className="fa fa-star"></i></li>
                                            <li className="star"><i className="fa fa-star"></i></li>
                                            <li className="star"><i className="fa fa-star"></i></li>
                                            <li className="star"><i className="fa fa-star"></i></li>
                                            <li className="star"><i className="fa fa-star"></i></li>
                                        </ul>

                                        <textarea name="review" id="review" className="form-control mt-3">

                                        </textarea>

                                        <button className="btn my-3 float-right review-btn px-4 text-white"  data-dismiss="modal" aria-label="Close">Submit</button>
                                    </div>
                                </div>
                            </div>
                        </div>

            </div> */}
                    
        </div>

        </div>
        </Fragment>
        }
    </Fragment>
    <div style={{marginTop: "10rem"}}>
          <div >

          </div>
        </div>
    </>
)}