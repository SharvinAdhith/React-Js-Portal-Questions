import { Link } from "react-router-dom";
import Search from "./Search";
import { useNavigate } from 'react-router-dom';
import Button from '@mui/material/Button';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import HomeIcon from '@mui/icons-material/Home';
import { useDispatch, useSelector } from "react-redux";
import { Dropdown, Image } from  'react-bootstrap';
import { logout } from "../actions/userActions";

export default function Header()
  {
   const {isAuthenticated, user} = useSelector(state => state.authState)
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const logoutHandler = () =>{
    dispatch(logout);
  }
  const {items:cartItems} = useSelector(state => state.cartState);
  const styleForPaper = {
    width: '6vw',
    height: '6vh',
    color: "white",
    
  };
    return (
     <nav className="navbar row " style={{maxHeight: "20vh"}}>
          
                <Link to="/home"><HomeIcon style={styleForPaper}></HomeIcon></Link>
                <h1 className="brand " style={{marginLeft:"5vh"}}>BookBuy</h1>
            <div  id="search" >
              <Search/>
            </div>
          
            <div className="col-12 col-md-3 mt-4 mt-md-0 text-center">
              { isAuthenticated ? 
                (
                  <Dropdown className="d-inline">
                      <Dropdown.Toggle variant='default text-white pr-5' id='dropdown-basic'>
                        <figure className='avatar avatar-nav'>
                            <Image width="50px" src={user.avatar??'./images/default_avatar.png'}/>
                        </figure>
                        <span>{user.name}</span>
                      </Dropdown.Toggle>
                      <Dropdown.Menu>
                        <Dropdown.Item onClick={()=> {navigate('/myProfile')}} className='text-dark'>Profile</Dropdown.Item>
                        <Dropdown.Item onClick={logoutHandler} className='text-danger'>Logout</Dropdown.Item>
                        <Dropdown.Item className='text-success'><Button variant="contained" onClick={() => navigate('/register')}  id="signup_btn" className="btn signup-button">Sign Up</Button>
                        </Dropdown.Item>
                      </Dropdown.Menu>
                  </Dropdown>
                )
              
               : 
               <Button variant="contained" onClick={() => navigate('/login')}  className="btn login-button" id="login_btn" >Login</Button>  
              }
              {/* <Button variant="contained" onClick={() => navigate('/register')}  class="btn" id="signup_btn" className="signup-button">Sign Up</Button> */}
              <Link  to={"/cart"} >
                    <Button href="#text-buttons" id="cart" className="ml-3"><ShoppingCartIcon/>
                    <span  id="cart_count">{cartItems.length}</span></Button>
              </Link> 
              
            </div>
            
        
        
      
        
    </nav>

)}