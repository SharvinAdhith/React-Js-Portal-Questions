import { Fragment, useEffect, useState } from 'react';
import MetaData from '../layouts/MetaData';
import { clearAuthError, login } from '../../actions/userActions';
import { useDispatch, useSelector } from 'react-redux';
import Button from '@mui/material/Button';
import { toast } from 'react-toastify';
import { useLocation, useNavigate } from 'react-router-dom';
import { Link } from "react-router-dom";

export default function Login() {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const location = useLocation(); 
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const redirect = location.search?'/'+location.search.split('=')[1]:'/home';
    const {  error, isAuthenticated , loading,} = useSelector(state => state.authState);//loading,
    const submitHandler = (e) => {
        e.preventDefault();
        dispatch(login(email, password))
    }
    useEffect(() => {
        if(isAuthenticated){
                navigate(redirect)
        }

        if(error){
            toast(error,{
                type: 'error',
                onOpen: ()=>{ dispatch(clearAuthError)}
            })
            return
        }
    },[error, isAuthenticated, dispatch,navigate,redirect])
    return(
        <>
        <Fragment>
            <MetaData title={'Login'}/>
        <div className="row wrapper"> 
		<div className="col-2 col-lg-4">
            
        <form onSubmit={submitHandler} className="shadow-lg">
            <h1 className="mb-3">Login</h1>
            <div className="form-group">
              <label htmlFor="email_field">Email</label>
              <input
                type="email"
                id="email_field"
                className="form-control"
                value={email}
                onChange={e => setEmail(e.target.value)}
              />
            </div>
  
            <div className="form-group">
              <label htmlFor="password_field">Password</label>
              <input
                type="password"
                id="password_field"
                className="form-control"
                value={password}
                onChange={e => setPassword(e.target.value)}
              />
            </div>

            <Link to="/password/forgot" className="float-right mb-4" style={{fontSize:"0.9em", color:"#ffffff"}}>Forgot Password?</Link>
          
            <Button
              variant="contained"
              id="login_button"
              type="submit"
              className="btn btn-block py-3"
              disabled={loading}
            >
              LOGIN
            </Button>
            
            <Link to="/register" className="float-right mt-3" style={{fontSize:"1.2em", color:"#ffffff"}}>Create a New Account?</Link>
            <div style={{marginTop: "2rem", color:"green"}}>
          <div >

          </div>
        </div>
          </form>
		  </div>
          <div></div>
        </div>
        </Fragment>
        <div style={{marginTop: "10rem"}}>
          <div >

          </div>
        </div>
      </>
    )
}