import React from 'react';
import Button from '@mui/material/Button';
import ButtonGroup from '@mui/material/ButtonGroup';
export default function Footer() {
    return  (
   
           

    <footer className="footer">
        <section >
           <h3>Contact Us</h3>
           <p>Have questions? Reach out to our customer support team 24/7 via phone or email.</p>
        
           <h3>Follow us on:</h3>
               <div className="social-media-icons">
               <ButtonGroup variant="text" aria-label="Basic button group">
                  <Button><a href="https://facebook.com">Facebook</a></Button>
                    <Button> <a href="https://twitter.com">Twitter</a></Button>
                    <Button>  <a href="https://instagram.com">Instagram</a></Button>
                </ButtonGroup>
                  
               </div> 
               <p className="text-center text-white mt-1 ">&copy; 2024 BBE LTD. All Rights Reserved.</p>
        </section>          
 </footer>
   )
}