import './App.css';
import Home from './pages/home';
import Header from './components/header';
import Footer from './components/footer';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import ProductDetail from './components/product/ProductDetail';
import {ToastContainer} from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Cart from './pages/Cart';
import Login from './components/user/Login';
import { HelmetProvider } from 'react-helmet-async';
import ProductSearch from './components/product/ProductSearch';
import Register from './components/user/Register';
import Profile from './components/user/Profile';
import ProtectedRoute from './route/ProtectedRoute';
import UpdateProfile from './components/user/UpdateProfile';
import UpdatePassword from './components/user/UpdatePassword';
import ForgotPassword from './components/user/ForgotPassword';
import ResetPassword from './components/user/ResetPassword';
import Shipping from './pages/Shipping';
import ConfirmOrder from './pages/ConfirmOrder';
import { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { loadUser } from './actions/userActions';
function App() {
  const dispatch = useDispatch();

  useEffect(() => {
    const user = localStorage.getItem("user");
    if (user) {
      dispatch(loadUser(JSON.parse(user))); 
    }
  }, [dispatch]);
  return (
  <Router>
    <div className="App">
      <HelmetProvider>
          <Header />  
          <div>
            <ToastContainer theme='dark' position= 'top-center' />
              <Routes>  
                <Route path="/home"  element={ <Home />}/> 
                <Route path="/search/:keyword"  element={ <ProductSearch />}/>
                <Route path="/product/:id" element={ <ProductDetail  /> } />
                <Route path="/login" element={<Login/>} />
                <Route path='/register' element={<Register/>}/>
                <Route path='/myprofile' element={ <ProtectedRoute> <Profile/></ProtectedRoute>}/>
                <Route path='/myprofile/update' element={ <ProtectedRoute> <UpdateProfile/></ProtectedRoute>}/>
                <Route path='/myprofile/update/password' element={ <ProtectedRoute> <UpdatePassword/></ProtectedRoute>}/>
                <Route path='/password/forgot' element={ <ForgotPassword/>} />
                <Route path='/password/reset/:token' element={ <ResetPassword/>} />
                <Route path="/cart" element={<Cart  />}></Route> 
                <Route path='/shipping' element={ <ProtectedRoute> <Shipping/></ProtectedRoute>}/>
                <Route path='/order/confirm' element={ <ProtectedRoute> <ConfirmOrder/></ProtectedRoute>}/>
            
             </Routes>
          </div>
        <Footer/>
      </HelmetProvider>
    </div>
</Router>
  );
}
export default App;