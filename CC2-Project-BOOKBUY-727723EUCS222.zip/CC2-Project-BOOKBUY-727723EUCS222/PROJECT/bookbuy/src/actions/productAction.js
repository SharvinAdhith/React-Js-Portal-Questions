import axios from 'axios';
import { productFail, productRequest, productSuccess } from '../slices/productSlice';

export const getProduct = id => async (dispatch) => {
    try {
        dispatch(productRequest())
        const { data } =  await axios.get(`/api/v1/product/${id}`);   //?page=1&price[gte]=200-postman url just for checking
        dispatch(productSuccess(data))
    } catch (error) {
        //handle error
        dispatch(productFail(error.response.data.message))
    }

}