import axios from 'axios';
import { productsFail, productsRequest, productsSuccess } from '../slices/productsSlice';

export const getProducts = (keyword, currentPage) => async (dispatch) => {
    try {
        dispatch(productsRequest())
        let link = `/api/v1/products?page=${currentPage}`;
        if(keyword){
            link += `&keyword=${keyword}`
        }
        const { data } =  await axios.get(link);   //?page=1&price[gte]=200-postman url just for checking
        dispatch(productsSuccess(data))
    } catch (error) {
        //handle error
        dispatch(productsFail(error.response.data.message))
    }

}
// export const getProducts = (keyword = '', currentPage = 1, minPrice = 1, maxPrice = 5000) => async (dispatch) => {
//     try {
//         const { data } = await axios.get(`/api/products?keyword=${keyword}&page=${currentPage}&minPrice=${minPrice}&maxPrice=${maxPrice}`);
//         dispatch({
//             type: 'GET_PRODUCTS_SUCCESS',
//             payload: data,
//         });
//     } catch (error) {
//         dispatch({
//             type: 'GET_PRODUCTS_FAIL',
//             payload: error.response.data.message,
//         });
//     }
// };