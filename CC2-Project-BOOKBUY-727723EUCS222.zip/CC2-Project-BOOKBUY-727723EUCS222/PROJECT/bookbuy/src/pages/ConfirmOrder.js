import { Fragment, useEffect } from "react";
import MetaData from "../components/layouts/MetaData";
import { validateShipping } from "./Shipping";
import { useDispatch, useSelector } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import CheckoutSteps from "./CheckoutStep";
import CurrencyRupeeIcon from '@mui/icons-material/CurrencyRupee';
import { cartClear } from "../slices/cartSlice";
import axios from "axios";
import { toast } from "react-toastify";

export default function ConfirmOrder(){
    const { shippingInfo, items:cartItems} = useSelector(state => state.cartState);
    const { user} = useSelector(state => state.authState);
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const itemsPrice = cartItems.reduce((acc, item)=> (acc + item.price * item.quantity), 0)
    const shippingPrice = itemsPrice > 500 ? 0 : 40;
    let taxPrice = Number( 0.05 * itemsPrice);
    const totalPrice = Number( itemsPrice + shippingPrice + taxPrice).toFixed(2);
    taxPrice = Number(taxPrice).toFixed(2);
    
    const processOrder = async () =>{
        const orderData = {
            orderItems: cartItems.map(item =>({
                product: item.product,
                quantity: item.quantity,
                price: item.price,
            })),
            shippingInfo,
            itemsPrice,
            shippingPrice,
            taxPrice,
            totalPrice,
            paymentInfo:{
                method: 'Razorpay - Debit Card',
                status: 'paid'
            }
        }
        try {
            const response = await axios.post('/api/v1/order/new', orderData, {
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${user.token}`
                }
            });  
            console.log('Order created successfully:', response.data);
            dispatch(cartClear());
            toast.success('Order placed successfully!', {
                position: 'bottom-center',
                autoClose: 2000, 
                
            });
            setTimeout(() => {
                navigate('/home');
            }, 3000);
        } catch (error) {
            console.error('Error creating order:', error);
            toast.error('Failed to place order. Please try again.', {
                position:'bottom-center',
                autoClose: 2000 
            });
        }
    };
    
    useEffect(()=>{
        validateShipping(shippingInfo, navigate)
    },[shippingInfo,navigate])
    return (
        <>
        <Fragment>
            <MetaData title={'Confirm Order'}/>
             <CheckoutSteps shipping confirmOrder />
        <div className="row d-flex justify-content-between">
            <div className="col-12 col-lg-8 mt-5 order-confirm">

                <h4 className="mb-3">Shipping Info</h4>
                <p><b>Name:</b> {user.name} </p>
                <p><b>Phone:</b> { shippingInfo.phoneNo }</p>
                <p className="mb-4"><b>Address:</b> { shippingInfo.address }, { shippingInfo.city }, { shippingInfo.postalCode},{ shippingInfo.state },{ shippingInfo.country } </p>
                <hr />
                <h4 className="mt-4">Your Cart Items:</h4>
                {cartItems.map(item => (
                    <Fragment>
                     
                    <div className="cart-item my-1">
                    <div className="row">
                        <div className="col-4 col-lg-2">
                            <img src={item.image} alt={item.name} height="80" width="65" />
                        </div>

                        <div className="col-5 col-lg-6">
                            <Link to={`/product/${item.product}`}>{item.name}</Link>
                        </div>

                       <div className="col-4 col-lg-4 mt-4 mt-lg-0">
                            <p>{item.quantity} x <CurrencyRupeeIcon/>{item.price} = <b><CurrencyRupeeIcon/>{item.quantity * item.price}</b></p>
                        </div>

                    </div>
                </div>
                <hr />
                </Fragment>
                )
            )
        }
   </div>
			
			<div className="col-12 col-lg-3 my-4">
                    <div id="order_summary">
                        <h4>Order Summary</h4>
                        <hr />
                        <p>Subtotal:  <span className="order-summary-values"><CurrencyRupeeIcon/>{itemsPrice}</span></p>
                        <p>Shipping: <span className="order-summary-values"><CurrencyRupeeIcon/>{shippingPrice}</span></p>
                        <p>Tax:  <span className="order-summary-values"><CurrencyRupeeIcon/>{taxPrice} </span></p>

                        <hr />

                        <p>Total: <span className="order-summary-values"><CurrencyRupeeIcon/>{totalPrice} </span></p>

                        <hr />
                        <button id="checkout_btn" className="btn btn-primary btn-block" onClick={processOrder} >Proceed to Order</button>
                    </div>
                </div>
			
			
        </div>
        </Fragment>
        <div style={{marginTop: "8rem"}}>
          <div >

          </div>
        </div>
        </>
    )
}