const express = require('express');
const app = express();
const errorMiddleware = require('./middlewares/error');
const cookieParser = require('cookie-parser')
const path = require('path')
const dotenv = require('dotenv');
const mongoose = require('mongoose');
dotenv.config({path:path.join(__dirname,"config/config.env")});
// Connect to MongoDB
const local = process.env.local;
const connectDB = async () => {
    try {
      await mongoose.connect(process.env.DB_URL);
      console.log(`MongoDB is connected to the host: ${local}`);
    } catch (err) {
      console.error(err.message);
      process.exit(1);
    }
  };
  connectDB();
  
  
app.use(express.json());
app.use(cookieParser());
app.use('/uploads', express.static(path.join(__dirname,'uploads') ) )

const products = require('./routes/product')
const auth = require('./routes/auth')
const order = require('./routes/order')
const payment = require('./routes/payment')

app.use('/api/v1/',products);
app.use('/api/v1/',auth);
app.use('/api/v1/',order);
app.use('/api/v1/',payment);

if(process.env.NODE_ENV === "production") {
    app.use(express.static(path.join(__dirname, '../bookbuy/build')));
    app.get('*', (req, res) =>{
        res.sendFile(path.resolve(__dirname, '../bookbuy/build/index.html'))
    })
}

app.use(errorMiddleware)
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT} in ${process.env.NODE_ENV} mode.`);
});
module.exports = app;